#!/bin/sh
exec jupyterhub-singleuser
